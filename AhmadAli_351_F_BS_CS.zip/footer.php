<footer class="page-footer font-small blue pt-4" style="
background-color: rgba(0,0,0,0.2) !important;color: white; position: relative; ">
  <div class="container-fluid text-center text-md-left">
    <div class="row">
      <div class="col-md-4 mt-md-0 mt-3">
        <h5 class="text-uppercase">Assignment No 2</h5>
        <p>Submitted To Sir Kamran Ullah</p>
          <p>BS.CS 6th Semester Section F</p>
      </div>
      <hr class="clearfix w-100 d-md-none pb-3">
      <div class="col-md-3 mb-md-0 mb-3">
        <h7 class="text-uppercase">Name</h7>
        <ul class="list-unstyled">
          <li>
            <h5>Ahmad Ali</h5>
          </li>
        </ul>
      </div>
      <div class="col-md-3 mb-md-0 mb-3">
          <h5 class="text-uppercase">Class No</h5>
        <ul class="list-unstyled">
          <li>
              <h3>351</h3>
          </li>
        </ul>
      </div>
    </div>
  </div>
  <div class="footer-copyright text-center py-3">© 2021 Copyright</div>
</footer>

